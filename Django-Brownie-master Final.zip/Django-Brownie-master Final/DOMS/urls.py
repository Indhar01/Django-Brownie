"""DOMS path Configuration

The `pathpatterns` list routes paths to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/paths/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a path to pathpatterns:  path(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a path to pathpatterns:  path(r'^$', Home.as_view(), name='home')
Including another pathconf
    1. Import the include() function: from django.conf.paths import path, include
    2. Add a path to pathpatterns:  path(r'^blog/', include('blog.paths'))
"""
from xml.etree.ElementInclude import include
import django
from django.contrib import admin
from orders import views as my_order
from django.contrib.auth import views as auth
from django.contrib.auth.decorators import login_required
from django.urls import path,re_path,reverse_lazy
from django.conf import settings
from django.conf.urls.static import static
from .settings import DEBUG,MEDIA_URL,MEDIA_ROOT
from orders import views
from django.contrib.auth.views import LoginView
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('index/', my_order.index, name='home'),
    path('', my_order.home, name='main-home'),
    path('orders/', my_order.index, name='home'),
    re_path(r'^order/(?P<order_id>\d+)/$', my_order.show, name='show'),
    path('order/new/', my_order.new, name='new'),
    re_path(r'^order/edit/(?P<order_id>\d+)/$', my_order.edit, name='edit'),
    re_path(r'^order/delete/(?P<order_id>\d+)/$', my_order.destroy, name='delete'),
    path('products/', my_order.index_product, name='home_product'),
    path('product/new/', my_order.new_product, name='new_product'),
    re_path(r'^product/delete/(?P<product_id>\d+)/$', my_order.destroy_product, name='delete_product'),
    re_path('users/login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('users/logout/',my_order.login_require, name='logout'),
    path('signup/', my_order.register_request, name="signup"),
    path('payment/',my_order.pay,name='payment'),
    re_path(r'^users/change_password/$', auth_views.PasswordChangeView.as_view(template_name='change_password.html',success_url = reverse_lazy('login')), name='change_password'),
    
]
if DEBUG:
     urlpatterns += static(MEDIA_URL, document_root=MEDIA_ROOT)