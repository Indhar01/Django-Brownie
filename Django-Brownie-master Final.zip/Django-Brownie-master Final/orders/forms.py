from django.forms import ModelForm
from django import forms
from .models import Order, Product
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django_select2.forms import ModelSelect2MultipleWidget


class OrderForm(ModelForm):
    OPTIONS = (
        ('Postpay','Postpay'),
        ('Prepay (Full)','Prepay (Full)'),
        ('Prepay (Half)', 'Prepay (Half)')
    )
    # OPTIONS1=('Dosa','Dosa'),('Idly','Idly'),('BreakFast','BreakFast')
    OPTIONS2 = (
        ('Confirm', 'Confirm'),
        ('Ready', 'Ready'),
        ('Send', 'Send'),
        ('Delivered', 'Delivered'),
        ('Returned', 'Returned'),
        ('Cancelled', 'Cancelled')
    )
    order_status = forms.TypedChoiceField(required=False, choices=OPTIONS2, widget=forms.RadioSelect)
    payment_option = forms.ChoiceField(choices=OPTIONS)
    product_id = forms.ModelChoiceField(queryset=Product.objects.filter(active='1'), empty_label='')
    # product_id = forms.MultipleChoiceField(widget=ModelSelect2MultipleWidget(),choices=OPTIONS1)
    delivery_date = forms.DateField(required=True)
    quantity = forms.IntegerField(initial=1)

    class Meta:
        model = Order
        fields = ['name','phone','address','delivery_date','product_id','payment_option','quantity','order_status']


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['product_name','product_image','product_details','price']

# class NewUserForm(UserCreationForm):
#     username=forms.CharField(required=True,label='username',max_length=32)
#     email=forms.CharField(required=True,label='email',max_length=32)
#     password=forms.CharField(required=True,label='password',max_length=32,widget=forms.PasswordInput)

#     class Meta:
#         model = User
#         fields = ("username", "email", "password")

#     def save(self, commit=True):
#         user = super(NewUserForm, self).save(commit=False)
#         user.email = self.cleaned_data['email']
#         if commit:
#             user.save()
#         return user
class RegisterForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class':'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password_repeat = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model = User
        fields = ("username", "email", "password","password_repeat")

    def save(self, commit=True):
        user = super(RegisterForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user
	
	
		
		

	
		
		
		
			
		

	
		
		

	# def save(self, commit=True):
	# 	user = super(NewUserForm, self).save(commit=False)
	# 	user.phone = self.cleaned_data['phone']
	# 	if commit:
	# 		user.save()
	# 	return user